"""Rule-based driver: speed planning, traffic, tyres and energy."""
import math


def clip(value, low, high):
    return max(low, min(high, value))


def plan_speed(o, current_curve):
    car = o["self"]
    rows = o["preview"]["rows"]
    wet = o["weather"]["track_wetness"]
    wear = max(car["tyre_wear"])
    # Lower lateral acceleration when grip is likely to be worse.
    grip = (1.0 - 0.40 * wet) * max(0.65, 1.0 -0.4 * wear)
    lateral_limit = 17.0 * grip
    braking = 13.0 * grip
    target = 75.0
    # The first preview point is 15 m ahead. Budget for actuator delay
    # and keep a local curvature limit until the car has crossed the apex.
    reaction_distance = car["speed_mps"] * 0.35 + 2.0
    target = min(target, math.sqrt(lateral_limit / max(current_curve, 0.001)))
    for row in rows:
        distance, curve = row[0], abs(row[1])
        remaining = max(0.0, distance - reaction_distance)
        corner_speed_sq = lateral_limit / max(curve, 0.001)
        target = min(target, math.sqrt(corner_speed_sq + 2 * braking * remaining))
    if abs(car["heading_error"]) > 0.3:
        target = min(target, 15.0)
    if car["fuel_kg"] < 5:
        target = min(target, 27.0)
    return target


def traffic_plan(o, target, offset, reserve=False):
    car = o["self"]
    n, speed = car["n"], car["speed_mps"]
    nearby = [r for r in o["rivals"] if r["status"] == "racing"]
    # Before moving toward the centre, allow a car alongside (or about to
    # draw alongside) to clear the lane. All distances below are in metres.
    for other in nearby:
        other_n = n + other["dn"]
        if abs(other_n - offset) >= abs(other["dn"]):
            continue
        if not min(n, offset) - 2.5 < other_n < max(n, offset) + 2.5:
            continue
        gap = other["gap_m"]
        next_gap = gap + 0.8 * (other["speed_mps"] - speed)
        if min(gap, next_gap) < 7.0 and max(gap, next_gap) > -7.0:
            offset = n
            break
    # A nearer car in the other column must not hide a slower leader.
    clearance = 2.7 if reserve else 2.5
    low, high = min(n, offset) - clearance, max(n, offset) + clearance
    braking = 4.0 * (1.0 - 0.4 * o["weather"]["track_wetness"])
    for other in nearby:
        gap, lead_speed = other["gap_m"], other["speed_mps"]
        if gap <= 0 or not low < n + other["dn"] < high:
            continue
        # Leave one car length and allow control response when closing.
        space = gap - (9.0 if reserve else 6.0) - 0.5 * max(0.0, speed - lead_speed)
        if space >= 0:
            cap = math.sqrt(lead_speed * lead_speed + 2.0 * braking * space)
        else:
            cap = max(0.0, lead_speed + space)
        target = min(target, cap)
    return target, offset


def choose_pit(o, wet_waiver):
    car = o["self"]
    if o["phase"] != "race" or car["pit_state"]:
        return False, "medium"
    # Schedule a soft-to-medium stop for the dry-compound rule.
    scheduled = not wet_waiver and car["pit_stops"] == 0 and car["lap"] >= 2
    worn = max(car["tyre_wear"]) > 0.75
    overheated = max(car["tyre_temp_c"]) > 130
    laps_left = o["laps_total"] -car["lap"]
    extra_stop = laps_left > 1 and (worn or overheated)
    compound = "hard" if car["compound"] == "medium" else "medium"
    return scheduled or extra_stop, compound


class Driver:
    def __init__(self):
        self.last_steer = 0.0
        self.last_phase = None
        self.recent_preview = []
        self.previous_station = None
        self.waiting_for = None
        self.wait_since = 0.0
        self.pass_seat = None
        self.pass_offset = 0.0
        self.rival_positions = {}
        self.rival_time = None

    def observe_lateral_motion(self, o):
        """Estimate rivals' road-relative motion from consecutive legal views."""
        now = o.get("time", o.get("tick", 0) / 60.0)
        dt = None if self.rival_time is None else now - self.rival_time
        current, rivals = {}, []
        for rival in o["rivals"]:
            row = dict(rival)
            if row["status"] == "racing":
                position = o["self"]["n"] + row["dn"]
                previous = self.rival_positions.get(row["seat"])
                rate = 0.0
                if previous is not None and dt is not None and 0 < dt <= 0.25:
                    rate = clip((position - previous) / dt, -4.0, 4.0)
                row["lateral_speed_mps"] = rate
                current[row["seat"]] = position
            rivals.append(row)
        self.rival_positions, self.rival_time = current, now
        # Keep the caller's observation and rival dictionaries untouched.
        return dict(o, rivals=rivals)

    def passing_line(self, o, target):
        car = o["self"]
        n = car["n"]
        others = [r for r in o["rivals"] if r["status"] == "racing"]
        if self.pass_seat is not None:
            leader = next((r for r in others if r["seat"] == self.pass_seat), None)
            if leader is not None and -12.0 < leader["gap_m"] < 50.0:
                lane = self.safe_offset(o, self.pass_offset)
                leader_n = n + leader["dn"]
                future_n = leader_n + 2.0 * leader.get("lateral_speed_mps", 0.0)
                squeezed = min(self.pass_side * (lane - leader_n),
                               self.pass_side * (lane - future_n)) < 3.3
                if not squeezed and self.corridor_free(car, others, lane, self.pass_seat):
                    return lane
                # A car has entered the planned lane, the leader is moving
                # over, or the road is narrowing. While alongside, hold the
                # current line. Move back only with room behind the leader.
                if leader["gap_m"] < 9.0:
                    return self.safe_offset(o, n)
                self.retry_at = o["time"] + 2.0
            elif abs(n - self.pass_offset) < 1.7 and not self.corridor_free(car, others, 0.0, None):
                # Passing the first car does not create a gap in a convoy.
                # Keep this lane until a return to the centre is clear.
                return self.safe_offset(o, self.pass_offset)
            self.pass_seat = None
            self.waiting_for = None

        if o["time"] < self.retry_at:
            return 0.0
        leaders = [r for r in others if 5.0 < r["gap_m"] < 27.0
                   and abs(r["dn"]) < 2.7 and target - r["speed_mps"] > 6.0]
        if not leaders:
            self.waiting_for = None
            return 0.0
        leader = min(leaders, key=lambda r: r["gap_m"])
        if self.waiting_for != leader["seat"]:
            self.waiting_for = leader["seat"]
            self.wait_since = o["time"]
        if o["time"] - self.wait_since < 1.5:
            return 0.0
        rows = o["preview"]["rows"][:6]
        if abs(car["heading_error"]) > 0.10 or max(abs(r[1]) for r in rows) > 0.004:
            return 0.0
        leader_n = n + leader["dn"]
        offsets = [leader_n + 3.8, leader_n - 3.8]
        # Prefer the shorter move, taking the wider side on equal choices.
        left, right = min(r[3] for r in rows), min(r[4] for r in rows)
        offsets.sort(key=lambda x: (round(abs(x - n), 1), -min(left - x, right + x)))
        for lane in offsets:
            if self.safe_offset(o, lane) != lane:
                continue
            side = 1.0 if lane > leader_n else -1.0
            future_n = leader_n + 2.0 * leader.get("lateral_speed_mps", 0.0)
            if side * (lane - future_n) < 3.3:
                continue
            if self.corridor_free(car, others, lane, leader["seat"]):
                self.pass_seat, self.pass_offset = leader["seat"], lane
                self.pass_side = 1.0 if lane > leader_n else -1.0
                return lane
        return 0.0

    @staticmethod
    def corridor_free(car, others, lane, leader_seat):
        n = car["n"]
        low, high = min(n, lane) - 2.7, max(n, lane) + 2.7
        for other in others:
            if other["seat"] == leader_seat:
                continue
            current_n = n + other["dn"]
            future_n = current_n + 2.0 * other.get("lateral_speed_mps", 0.0)
            lateral_low, lateral_high = min(current_n, future_n), max(current_n, future_n)
            if not (lateral_low < high and lateral_high > low):
                continue
            gap = other["gap_m"]
            relative = other["speed_mps"] - car["speed_mps"]
            in_destination = lateral_low < lane + 2.7 and lateral_high > lane - 2.7
            if in_destination:
                projected = gap + 2.0 * relative
                rear, front = -18.0, 38.0
            else:
                # The current/swept lane is only occupied during the change.
                # Longitudinal following still covers the whole swept width.
                projected = gap + 1.5 * relative
                rear, front = -8.0, 8.0
            if min(gap, projected) < front and max(gap, projected) > rear:
                return False
        return True

    @staticmethod
    def safe_offset(o, lane):
        rows = o["preview"]["rows"][:6]
        return clip(lane, -min(r[4] for r in rows) + 2.7, min(r[3] for r in rows) - 2.7)

    def act(self, o):
        car = o["self"]
        if self.last_phase != o["phase"]:
            self.last_steer = 0.0
            self.last_phase = o["phase"]
            self.recent_preview = []
            self.previous_station = None
            self.start_distance = car.get("distance", car["s"])
            self.grid_lane = car["n"]
            self.hairpin_preview = {}
            self.wet_waiver = False
            self.waiting_for = self.pass_seat = None
            self.retry_at = 0.0
            self.rival_positions, self.rival_time = {}, None
        o = self.observe_lateral_motion(o)
        if o["phase"] == "race" and o["weather"]["track_wetness"] >= 0.5:
            self.wet_waiver = True
        station = car["s"]
        if self.previous_station is not None and station < self.previous_station:
            self.recent_preview = []  # Lap seam or reset.
        self.previous_station = station
        distance, curvature = o["preview"]["rows"][0][:2]
        # Store one curvature maximum per 1 m bin. This bounds storage even
        # when the car is stopped or creeping towards a corner.
        bucket = math.floor(station + distance)
        self.recent_preview = [(i, k) for i, k in self.recent_preview if i + 1 >= station]
        if self.recent_preview and self.recent_preview[-1][0] == bucket:
            self.recent_preview[-1] = (bucket, max(self.recent_preview[-1][1], abs(curvature)))
        else:
            self.recent_preview.append((bucket, abs(curvature)))
        current_curve = max(k for _, k in self.recent_preview)
        target = plan_speed(o, current_curve)
        offset = 0.0
        # Stay in the starting lane in a crowded grid. Ease to the normal
        # traffic planner after the first 70 m, completing the merge by 150 m.
        lateral_error = abs(car["n"])
        passing_enabled = False
        if o["phase"] == "race":
            travelled = car.get("distance", station) - self.start_distance
            blend = clip((travelled - 70.0) / 80.0, 0.0, 1.0)
            fraction = blend * blend * (3.0 - 2.0 * blend)
            offset = (1.0 - fraction) * self.grid_lane + fraction * offset
            safety_car = o.get("safety_car", False)
            if isinstance(safety_car, dict):
                safety_car = safety_car.get("active", False)
            passing_enabled = (abs(o["track_length_m"] - 5803.167) < 0.5 and travelled > 160.0
                               and not car["pit_state"] and not safety_car)
            if passing_enabled:
                offset = self.passing_line(o, target)
            else:
                self.pass_seat = self.waiting_for = None
        target, offset = traffic_plan(o, target, offset, reserve=passing_enabled)
        if o["phase"] == "race" and (travelled < 150.0 or self.pass_seat is not None):
            lateral_error = abs(car["n"] - offset)
        # Project the near-term lateral drift in road coordinates. The
        # nearest cross-section available in the observation is 15 m ahead.
        left, right = o["preview"]["rows"][0][3:5]
        heading = car["heading_error"]
        lateral_speed = (car.get("vx", car["speed_mps"]) * math.sin(heading)
                         + car.get("vy", 0.0) * math.cos(heading))
        projected_n = car["n"] + 0.6 * lateral_speed
        boundary_margin = min(left - max(car["n"], projected_n),
                              right + min(car["n"], projected_n))
        if lateral_error > 3.0 or boundary_margin <= 2.0:
            target = min(target, 15.0)
        curve = o["preview"]["rows"][0][1]
        # Highland's opening hairpin spans stations 205–260 m. At low speed
        # the +15 m preview starts steering while the car is still on the
        # straight. For that first approach, use the previously observed
        # bend about 5 m ahead. Speed planning still sees the full preview.
        if (o["phase"] == "race" and car["lap"] == 0
                and abs(o["track_length_m"] - 6999.367) < 0.5
                and 170.0 <= station <= 275.0):
            self.hairpin_preview[bucket] = curve
            wanted = station + 5.0
            self.hairpin_preview = {i: k for i, k in self.hairpin_preview.items()
                                    if i + 1.0 >= wanted}
            nearest = min(self.hairpin_preview, key=lambda i: abs(i - wanted))
            curve = self.hairpin_preview[nearest]
        elif self.hairpin_preview:
            self.hairpin_preview.clear()
        # Road curvature plus heading and position feedback.
        turn = 3.4 * curve -0.6 * car["heading_error"]
        correction = turn -0.04 * (car["n"] -offset)
        desired = clip(correction / 0.30, -1, 1)
        steer = clip(desired, self.last_steer -0.15,
                     self.last_steer + 0.15)
        self.last_steer = steer
        error = target -car["speed_mps"]
        throttle = clip(error * 0.45, 0.0, 1.0)
        brake = clip(-error * 0.32, 0.0, 1.0)
        # Reduce power while recovering from a large heading error.
        if abs(car["heading_error"]) > 0.6:
            throttle = min(throttle, 0.25)
        if car["fuel_kg"] < 5:
            throttle = min(throttle, 0.65)
        rows = o["preview"]["rows"][:6]
        straight = max(abs(row[1]) for row in rows) < 0.002
        boost = straight and error > 1 and car["ers_soc_mj"] > 1.5
        pit, compound = choose_pit(o, self.wet_waiver)
        if car["pit_state"]:
            throttle, brake, steer = 0.0, 0.0, 0.0
        return {
            "throttle": throttle, "brake": brake, "steer": steer,
            "ers_mode": 2 if boost else 1,
            "aero_mode": 0,
            "pit_request": bool(pit), "pit_compound": compound
        }


_driver = Driver()


def init(context):
    global _driver
    _driver = Driver()


def act(observation):
    return _driver.act(observation)
